from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('trainers/', views.trainers, name='trainers'),
    path('workouts/', views.workouts, name='workouts'),
    path('member/<int:pk>/', views.member_detail, name='member_detail'),
    path('trainer/<int:pk>/', views.trainer_detail, name='trainer_detail'),
]
