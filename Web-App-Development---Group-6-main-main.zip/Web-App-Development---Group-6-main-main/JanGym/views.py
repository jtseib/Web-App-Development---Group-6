from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, get_object_or_404
from .models import Member, Trainer

# Create your views here.

def index(request):
    return render(request, 'index.html')


def trainers(request):
    return render(request, 'trainers.html')


def workouts(request):
    return render(request, 'workouts.html')


def member_detail(request, pk):
    member = get_object_or_404(Member, pk=pk)
    return render(request, 'member_detail.html', {'member': member})


def trainer_detail(request, pk):
    trainer = get_object_or_404(Trainer, pk=pk)
    return render(request, 'trainer_detail.html', {'trainer': trainer})